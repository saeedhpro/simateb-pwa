import '/assets/font-awesome/all.min.css'
import '/assets/font-awesome/all.min.js'
export default defineNuxtPlugin((app) => {

})