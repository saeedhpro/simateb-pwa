export default defineEventHandler((event) => {
    return {
        data: [
            {
                id: 1,
                description: 'امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد. امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد',
                images: [
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                ]
            },
            {
                id: 2,
                description: 'امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد. امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد',
                images: [
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                ]
            },
            {
                id: 3,
                description: 'امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد. امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد',
                images: [
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                ]
            },
            {
                id: 4,
                description: 'امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد. امیر 28 ساله از ملایر که بعد از احساس تنفس سخت از راه بینی به پرشک مراجعه کرد',
                images: [
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                    '/images/samples/sample_1.png',
                ]
            },
        ]
    }
})