export default defineEventHandler((event) => {
    return {
        data: [
            {
                id: 1,
                name: 'ارتودنسی'
            },
            {
                id: 2,
                name: 'ارتودنسی'
            },
            {
                id: 3,
                name: 'ارتودنسی'
            },
            {
                id: 4,
                name: 'ارتودنسی'
            },
            {
                id: 5,
                name: 'ارتودنسی'
            },
            {
                id: 6,
                name: 'ارتودنسی'
            },
            {
                id: 7,
                name: 'ارتودنسی'
            },
            {
                id: 8,
                name: 'ارتودنسی'
            },
            {
                id: 9,
                name: 'ارتودنسی'
            },
            {
                id: 10,
                name: 'ارتودنسی'
            },
        ]
    }
})