export default defineEventHandler((event) => {
    return {
        data: [
            {
                id: 1,
                title: 'علت نازک‌ شدن مو چیست و چگونه می‌توان آن را متوقف کرد؟',
                thumbnail: '/images/blog/1.png',
                created_at_fa: 'سه‌شنبه ۲ آبان ۱۴۰۲ - ۱۲:۰۰',
            },
            {
                id: 2,
                title: 'علت نازک‌ شدن مو چیست و چگونه می‌توان آن را متوقف کرد؟',
                thumbnail: '/images/blog/1.png',
                created_at_fa: 'سه‌شنبه ۲ آبان ۱۴۰۲ - ۱۲:۰۰',
            },
            {
                id: 3,
                title: 'علت نازک‌ شدن مو چیست و چگونه می‌توان آن را متوقف کرد؟',
                thumbnail: '/images/blog/1.png',
                created_at_fa: 'سه‌شنبه ۲ آبان ۱۴۰۲ - ۱۲:۰۰',
            },
            {
                id: 4,
                title: 'علت نازک‌ شدن مو چیست و چگونه می‌توان آن را متوقف کرد؟',
                thumbnail: '/images/blog/1.png',
                created_at_fa: 'سه‌شنبه ۲ آبان ۱۴۰۲ - ۱۲:۰۰',
            },
            {
                id: 5,
                title: 'علت نازک‌ شدن مو چیست و چگونه می‌توان آن را متوقف کرد؟',
                thumbnail: '/images/blog/1.png',
                created_at_fa: 'سه‌شنبه ۲ آبان ۱۴۰۲ - ۱۲:۰۰',
            },
        ]
    }
})