export default defineEventHandler((event) => {
    return {
        data: [
            {
                id: 1,
                title: 'جراحی بینی',
                sub_title: 'نمونه جراحی های بینی انجام شده',
                image: '/images/samples/sample_1.png',
            },
            {
                id: 2,
                title: 'جراحی بینی',
                sub_title: 'نمونه جراحی های بینی انجام شده',
                image: '/images/samples/sample_1.png',
            },
            {
                id: 3,
                title: 'جراحی بینی',
                sub_title: 'نمونه جراحی های بینی انجام شده',
                image: '/images/samples/sample_1.png',
            },
            {
                id: 4,
                title: 'جراحی بینی',
                sub_title: 'نمونه جراحی های بینی انجام شده',
                image: '/images/samples/sample_1.png',
            },
        ]
    }
})