export default defineEventHandler((event) => {
    return {
        data: [
            {
                id: 1,
                title: 'دندان',
            },
            {
                id: 2,
                title: 'جراحی',
            },
            {
                id: 3,
                title: 'بیماری',
            },
            {
                id: 4,
                title: 'سلامت زنان',
            },
            {
                id: 5,
                title: 'رژیم و تغذیه',
            },
        ]
    }
})